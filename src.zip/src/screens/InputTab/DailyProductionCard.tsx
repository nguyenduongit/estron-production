// src/screens/InputTab/components/DailyProductionCard.tsx
import React, { useState, useEffect, useCallback } from 'react'; // Thêm useEffect, useCallback
import { View, Text, StyleSheet, TouchableOpacity, TextInput as RNTextInput, Alert } from 'react-native'; // Thêm Alert
import Ionicons from '@expo/vector-icons/Ionicons';

import { theme } from '../../theme';
import { DailyProductionData, DailySupplementaryData } from '../../types/data'; // Thêm DailySupplementaryData
import Card from '../../components/common/Card';
// Import hàm lưu trữ
import {
  addOrUpdateDailySupplementaryData,
  getSupplementaryDataByDateFromStorage
} from '../../services/storage'; // Giả sử đường dẫn đúng

interface DailyProductionCardProps {
  dailyInfo: DailyProductionData;
  weekHasData: boolean;
  onAddProduction: (date: string) => void;
}

const HOUR_OPTIONS = [1, 2, 3, 4, 8];

const DailyProductionCard: React.FC<DailyProductionCardProps> = ({
  dailyInfo,
  weekHasData,
  onAddProduction,
}) => {
  const [isExpanded, setIsExpanded] = useState(false);
  const [isLoadingSupp, setIsLoadingSupp] = useState(false); // State cho việc tải dữ liệu phụ trợ

  // State cho giá trị hiện tại của các input phụ trợ
  const [currentLeaveHours, setCurrentLeaveHours] = useState<number | null | undefined>(undefined);
  const [currentOvertimeHours, setCurrentOvertimeHours] = useState<number | null | undefined>(undefined);
  const [currentMeetingMinutes, setCurrentMeetingMinutes] = useState<string>('');


  // Tải dữ liệu phụ trợ khi card được hiển thị hoặc ngày thay đổi
  useEffect(() => {
    const loadSuppData = async () => {
      if (!dailyInfo.date) return;
      setIsLoadingSupp(true);
      try {
        const suppData = await getSupplementaryDataByDateFromStorage(dailyInfo.date);
        if (suppData) {
          setCurrentLeaveHours(suppData.leaveHours);
          setCurrentOvertimeHours(suppData.overtimeHours);
          setCurrentMeetingMinutes(suppData.meetingMinutes?.toString() || '');
        } else {
          // Reset nếu không có dữ liệu
          setCurrentLeaveHours(undefined);
          setCurrentOvertimeHours(undefined);
          setCurrentMeetingMinutes('');
        }
      } catch (error) {
        console.error("Error loading supplementary data for card:", error);
        // Có thể reset state ở đây nếu cần
      } finally {
        setIsLoadingSupp(false);
      }
    };
    loadSuppData();
  }, [dailyInfo.date]);


  const handleSaveSupplementaryData = useCallback(async (field: keyof Omit<DailySupplementaryData, 'date'>, value: number | string | null) => {
    const dataToSave: DailySupplementaryData = {
        date: dailyInfo.date,
    };

    if (field === 'leaveHours') dataToSave.leaveHours = value as number | null;
    else dataToSave.leaveHours = currentLeaveHours === undefined ? null : currentLeaveHours; // Giữ giá trị hiện tại nếu không phải field đang thay đổi

    if (field === 'overtimeHours') dataToSave.overtimeHours = value as number | null;
    else dataToSave.overtimeHours = currentOvertimeHours === undefined ? null : currentOvertimeHours;

    if (field === 'meetingMinutes') dataToSave.meetingMinutes = value === '' || value === null ? null : Number(value);
    else dataToSave.meetingMinutes = currentMeetingMinutes === '' ? null : Number(currentMeetingMinutes);


    // Đảm bảo các giá trị không được set là undefined mà là null nếu rỗng
    if (dataToSave.leaveHours === undefined) dataToSave.leaveHours = null;
    if (dataToSave.overtimeHours === undefined) dataToSave.overtimeHours = null;
    if (dataToSave.meetingMinutes === undefined || isNaN(dataToSave.meetingMinutes as number)) dataToSave.meetingMinutes = null;


    try {
      await addOrUpdateDailySupplementaryData(dataToSave);
      // console.log(`Saved ${field} for ${dailyInfo.date}:`, value);
    } catch (error) {
      console.error(`Error saving ${field} for ${dailyInfo.date}:`, error);
      Alert.alert("Lỗi", `Không thể lưu dữ liệu ${field}.`);
    }
  }, [dailyInfo.date, currentLeaveHours, currentOvertimeHours, currentMeetingMinutes]);


  const handleHourOptionPress = (type: 'leaveHours' | 'overtimeHours', hours: number) => {
    if (type === 'leaveHours') {
      const newValue = currentLeaveHours === hours ? null : hours;
      setCurrentLeaveHours(newValue);
      handleSaveSupplementaryData('leaveHours', newValue);
    } else {
      const newValue = currentOvertimeHours === hours ? null : hours;
      setCurrentOvertimeHours(newValue);
      handleSaveSupplementaryData('overtimeHours', newValue);
    }
  };

  const handleMeetingMinutesChange = (text: string) => {
    const newMinutes = text.replace(/[^0-9]/g, '');
    setCurrentMeetingMinutes(newMinutes);
    // Lưu khi người dùng ngừng nhập hoặc khi input mất focus (onBlur)
  };

  const handleMeetingMinutesBlur = () => {
    const minutesToSave = currentMeetingMinutes === '' ? null : Number(currentMeetingMinutes);
    handleSaveSupplementaryData('meetingMinutes', minutesToSave);
  };


  return (
    <Card style={styles.dailyCard}>
      <View style={styles.cardHeader}>
        <Text style={styles.cardDateText}>{`${dailyInfo.dayOfWeek}, ${dailyInfo.formattedDate}`}</Text>
        {weekHasData && <Text style={styles.cardTotalWorkText}>Tổng công: {dailyInfo.totalWorkForDay || '0'}</Text>}
      </View>

      <View style={styles.entriesContainer}>
        {/* ... (phần hiển thị entry không đổi) ... */}
         {dailyInfo.entries.length > 0 ? (
          dailyInfo.entries.map((entry, index) => (
            <React.Fragment key={`${dailyInfo.date}-${entry.stageCode}-${index}`}>
              <View style={styles.entryRow}>
                <Text style={styles.entryStageCode}>{entry.stageCode}</Text>
                <Text style={styles.entryQuantity}>{entry.quantity}</Text>
              </View>
              {dailyInfo.entries.length > 1 && index < dailyInfo.entries.length - 1 && (
                <View style={styles.divider} />
              )}
            </React.Fragment>
          ))
        ) : (
          <Text style={styles.noEntryText}>Chưa có dữ liệu</Text>
        )}
      </View>

      <View style={styles.footerActionContainer}>
        <TouchableOpacity
          style={styles.addProductionButton}
          onPress={() => onAddProduction(dailyInfo.date)}
        >
          <Ionicons name="add-circle-outline" size={22} color={theme.colors.primary} />
          <Text style={styles.addProductionButtonText}>Thêm sản lượng</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={styles.expandButton}
          onPress={() => setIsExpanded(!isExpanded)}
        >
          <Ionicons
            name={isExpanded ? "chevron-up-outline" : "chevron-down-outline"}
            size={24}
            color={theme.colors.secondary}
          />
        </TouchableOpacity>
      </View>

      {isExpanded && (
        <View style={styles.additionalSection}>
          {isLoadingSupp && <Text style={styles.loadingText}>Đang tải...</Text>}
          {/* Nghỉ */}
          <View style={styles.additionalRow}>
            <Text style={styles.additionalLabel}>Nghỉ:</Text>
            <View style={styles.optionsContainer}>
              {HOUR_OPTIONS.map(hours => (
                <TouchableOpacity
                  key={`leave-${hours}`}
                  style={[
                    styles.hourOptionButton,
                    currentLeaveHours === hours && styles.hourOptionSelected,
                  ]}
                  onPress={() => handleHourOptionPress('leaveHours', hours)}
                >
                  <Text
                    style={[
                      styles.hourOptionText,
                      currentLeaveHours === hours && styles.hourOptionSelectedText,
                    ]}
                  >
                    {hours}h
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
          </View>

          {/* Tăng ca */}
          <View style={styles.additionalRow}>
            <Text style={styles.additionalLabel}>Tăng ca:</Text>
            <View style={styles.optionsContainer}>
              {HOUR_OPTIONS.map(hours => (
                <TouchableOpacity
                  key={`overtime-${hours}`}
                  style={[
                    styles.hourOptionButton,
                    currentOvertimeHours === hours && styles.hourOptionSelected,
                  ]}
                  onPress={() => handleHourOptionPress('overtimeHours', hours)}
                >
                  <Text
                    style={[
                      styles.hourOptionText,
                      currentOvertimeHours === hours && styles.hourOptionSelectedText,
                    ]}
                  >
                    {hours}h
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
          </View>

          {/* Họp/Đào tạo */}
          <View style={styles.additionalRow}>
            <Text style={styles.additionalLabel}>Họp/Đào tạo:</Text>
            <View style={styles.meetingInputContainer}>
              <RNTextInput
                style={styles.meetingInput}
                value={currentMeetingMinutes}
                onChangeText={handleMeetingMinutesChange}
                onBlur={handleMeetingMinutesBlur} // Lưu khi mất focus
                keyboardType="numeric"
                placeholder="Số phút"
                placeholderTextColor={theme.colors.grey}
              />
               <Text style={styles.unitLabel}>phút</Text>
            </View>
          </View>
        </View>
      )}
    </Card>
  );
};

// Styles không thay đổi nhiều, chỉ thêm loadingText
const styles = StyleSheet.create({
  // ... (tất cả styles hiện có của bạn)
  dailyCard: {
    marginVertical: theme.spacing.sm,
    padding: 0,
    borderRadius: 8,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: theme.colors.borderColor,
  },
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingBottom: theme.spacing.sm,
    paddingTop: theme.spacing.sm,
    paddingHorizontal: theme.spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: theme.colors.borderColor,
    backgroundColor: theme.colors.lightGrey,
  },
  cardDateText: {
    fontSize: theme.typography.body.fontSize,
    fontWeight: 'bold',
    color: theme.colors.text,
  },
  cardTotalWorkText: {
    fontSize: theme.typography.bodySmall.fontSize,
    fontWeight: 'bold',
    color: theme.colors.info,
  },
  entriesContainer: {
    paddingBottom: theme.spacing.xs,
  },
  entryRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingHorizontal: theme.spacing.md,
    paddingVertical: theme.spacing.sm,
  },
  entryStageCode: {
    fontSize: theme.typography.bodySmall.fontSize,
    fontWeight: 'bold',
    color: theme.colors.text,
  },
  entryQuantity: {
    fontSize: theme.typography.bodySmall.fontSize,
    fontWeight: 'bold',
    color: theme.colors.text,
  },
  noEntryText: {
    fontSize: theme.typography.bodySmall.fontSize,
    color: theme.colors.textSecondary,
    textAlign: 'center',
    paddingVertical: theme.spacing.md,
    paddingHorizontal: theme.spacing.md,
  },
  divider: {
    height: 1,
    backgroundColor: theme.colors.borderColor,
    marginHorizontal: theme.spacing.md,
  },
  footerActionContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: theme.spacing.xs,
    paddingHorizontal: theme.spacing.md,
    borderTopWidth: 1,
    borderTopColor: theme.colors.lightGrey,
  },
  addProductionButton: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: theme.spacing.sm / 2,
  },
  addProductionButtonText: {
    marginLeft: theme.spacing.xs,
    color: theme.colors.primary,
    fontSize: theme.typography.bodySmall.fontSize,
    fontWeight: 'bold',
  },
  expandButton: {
    padding: theme.spacing.sm,
  },
  additionalSection: {
    paddingHorizontal: theme.spacing.md,
    paddingVertical: theme.spacing.sm,
    borderTopWidth: 1,
    borderTopColor: theme.colors.borderColor,
    backgroundColor: theme.colors.background,
  },
  additionalRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: theme.spacing.sm,
  },
  additionalLabel: {
    fontSize: theme.typography.bodySmall.fontSize,
    color: theme.colors.textSecondary,
    marginRight: theme.spacing.sm,
    flex: 0.3,
  },
  optionsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    flexWrap: 'nowrap',
    flex: 0.7,

  },
  hourOptionButton: {
    height: 28,
    minWidth: 40,
    paddingHorizontal: theme.spacing.sm,
    paddingVertical: theme.spacing.xs,
    borderRadius: theme.borderRadius.sm,
    borderColor: theme.colors.primary,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,

  },
  hourOptionSelected: {
    backgroundColor: theme.colors.primary,
  },
  hourOptionText: {
    fontSize: theme.typography.caption.fontSize,
    color: theme.colors.primary,
  },
  hourOptionSelectedText: {
    color: theme.colors.white,
  },
  meetingInputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 0.69,
    borderWidth: 1,
    borderColor: theme.colors.primary,
    borderRadius: theme.borderRadius.sm,
  },
  meetingInput: {
    flex: 1,
    height: 30,
    fontSize: theme.typography.bodySmall.fontSize,
    paddingLeft: theme.spacing.sm,
    color: theme.colors.text,
  },
  unitLabel: {
    fontSize: theme.typography.bodySmall.fontSize,
    color: theme.colors.textSecondary,
    paddingHorizontal: theme.spacing.sm,
  },
  loadingText: { // Style cho text loading
    fontSize: theme.typography.caption.fontSize,
    color: theme.colors.textSecondary,
    textAlign: 'center',
    paddingVertical: theme.spacing.sm,
  }
});

export default DailyProductionCard;